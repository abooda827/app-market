export interface Good{
    id?: string;
    name?: string;
    price?: number;
    imageUrl?: string;
}