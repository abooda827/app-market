export interface shopping{
    id?:string;
    name?: string;
    price?: number;
    amount?:number;
}