export interface User{
    id?: string;
    admin?:string;
    name?: string;
    email?: string;
    password?: string;
    address?: string;
    phone?: number;
    imageUrl?: string;
}